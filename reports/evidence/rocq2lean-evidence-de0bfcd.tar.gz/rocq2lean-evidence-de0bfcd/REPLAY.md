# Evidence package de0bfcd

Source revision `de0bfcd7c24550d2068bbef53150d0ee148c70f0` (`source/`, from `git archive`). Toolchains: `toolchains.lock.json`
(Lean v4.33.1; Rocq 9.3.0, opam switch `rocq930`, MetaRocq Template c18395ad unpatched).
Toolchain setup: `source/docs/REPRODUCE.md`. The toolchain binaries' content digests used by this
run are in `run-m3d/verify.json` (`toolchain_fingerprint`).

## The packaged chain (`run-m3d/`)

Roots (original Rocq induction proofs, `fixtures/m3/M3Proofs.v`): `M3.M3Proofs.addR_n_RZ, M3.M3Proofs.length_map, M3.M3Proofs.mirror_mirror, M3.M3Proofs.vmap_id, M3.M3Proofs.vid_id`.
Commands and outputs: `run-m3d/logs/cli.log` (export with independent round trip, translate,
verify, status, kernel replay of the report). Verdict: `run-m3d/verify.json` (status VERIFIED), with
every bound digest (`bound_sha256`); consumer detectors `run-m3d/consumer_result.json`; independent
audit `run-m3d/audit.json`; kernel replay from the report alone `run-m3d/replay.json`; Rocq/Lean
computation agreement `run-m3d/computation.json` and law table `run-m3d/m3_laws.json`.

## Replaying

1. `cd source && lake build Rocq2Lean Smoke && ./scripts/doctor`
2. Full suite: `./scripts/test-all`; acceptance: `./scripts/acceptance`.
3. Re-run the chain: `./scripts/rocq2lean export --manifest fixtures/m3/manifest.json --roots M3.M3Proofs.addR_n_RZ,M3.M3Proofs.length_map,M3.M3Proofs.mirror_mirror,M3.M3Proofs.vmap_id,M3.M3Proofs.vid_id --out RUN`,
   then `translate --input RUN/source.ndjson --out RUN`, `verify --run RUN`, `status --run RUN`.
   Bound digests equal `run-m3d/verify.json` except those of the IR-derived contract/snapshot
   (fresh run id) and absolute paths.
4. Check this archive: `sha256sum -c SHA256SUMS`.
