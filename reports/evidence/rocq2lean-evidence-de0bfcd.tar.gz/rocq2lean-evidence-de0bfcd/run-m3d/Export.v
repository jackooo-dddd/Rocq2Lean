From Rocq2LeanExport Require Import Loader.
Require M3.M3Types.
Require M3.M3Case.
Require M3.M3Fix.
Require M3.M3Proofs.
Require M3.M3Neg.
Rocq2Lean Export "/home/shunqwang4/research/Rocq2Lean/runs/evidence-m3d/source.ndjson" M3.M3Proofs.addR_n_RZ M3.M3Proofs.length_map M3.M3Proofs.mirror_mirror M3.M3Proofs.vmap_id M3.M3Proofs.vid_id.
