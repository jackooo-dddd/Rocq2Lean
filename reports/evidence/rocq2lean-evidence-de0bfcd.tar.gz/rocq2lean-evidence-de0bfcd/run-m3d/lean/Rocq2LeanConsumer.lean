import Rocq2LeanOut
import Rocq2Lean.Verify
#rocq2lean_verify "/home/shunqwang4/research/Rocq2Lean/runs/evidence-m3d/contract.json" "/home/shunqwang4/research/Rocq2Lean/runs/evidence-m3d/translation_report.json" "/home/shunqwang4/research/Rocq2Lean/runs/evidence-m3d/consumer_result.json"
