import Rocq2Lean
#rocq2lean_import "/home/shunqwang4/research/Rocq2Lean/runs/evidence-m3d/source.ndjson" "/home/shunqwang4/research/Rocq2Lean/runs/evidence-m3d/translation_report.json" "6be2f923de7694c445ca431cc6934bf43ba46bc6cfab32a42b7e9ade167903a3" "e3f8e7df-b42e-4999-8f34-6e1ca64f3c48"
